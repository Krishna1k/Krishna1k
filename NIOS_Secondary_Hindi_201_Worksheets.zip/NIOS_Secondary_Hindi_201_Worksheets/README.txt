==========================================================
 NIOS SECONDARY (Class 10) HINDI - 201
 WORKSHEETS  (Official NIOS - 14 worksheets)
==========================================================

ZAROORI BAAT (padho pehle):
---------------------------
NIOS ke worksheet PDFs is server par hain:
   www.nios.ac.in  (media folder)

Ye server sirf India ke network/browser se khulta hai. Jis
automated environment me ye zip banaya gaya hai, wahan se
www.nios.ac.in block tha (connection time out), isliye
worksheet PDFs ko seedha download karke zip me daal nahi paaye.

GOOD NEWS: aapke apne browser/laptop (India) se ye links bilkul
khulte hain. Isliye is zip me 3 aasaan tareeke diye hain jisse
saari 14 worksheets ek click/command me download ho jayengi.

----------------------------------------------------------
 TAREEKA 1 (sabse aasaan) - Browser se one-click
----------------------------------------------------------
- "Download_All_Worksheets.html" file ko apne browser me kholo
  (double click).
- Page par "Download all" button dabao, ya har link par click
  karo. Saari PDFs aapke Downloads folder me aa jayengi.

----------------------------------------------------------
 TAREEKA 2 - Terminal (Mac/Linux) ya Git-Bash (Windows)
----------------------------------------------------------
   bash download_worksheets.sh
   (PDFs "worksheets/" folder me save hongi)

----------------------------------------------------------
 TAREEKA 3 - Python (koi bhi OS)
----------------------------------------------------------
   python3 download_worksheets.py

----------------------------------------------------------
 Files ki list (14 worksheets + 1 instruction sheet)
----------------------------------------------------------
worksheet1.pdf   -> Paath 1
worksheet2.pdf   -> Paath 2
worksheet3.pdf   -> Paath 3
201_ws_H_4.pdf   -> Paath 4
201_ws_H_5.pdf   -> Paath 5
201_ws_H_6.pdf   -> Paath 6
201_ws_H_7.pdf   -> Paath 7
201_ws_H_8.pdf   -> Paath 8
201_ws_H_9.pdf   -> Paath 9
201_ws_H_10.pdf  -> Paath 10
201_ws_H_11.pdf  -> Paath 11
201_ws_H_12.pdf  -> Paath 12
201_ws_H_13.pdf  -> Paath 13
201_ws_H_14.pdf  -> Paath 14
Instructions_for_Worksheet-ed.pdf -> Worksheet kaise karni hai

Saare direct links "worksheet_links.txt" me bhi hain.

Source / official subject page:
  https://www.nios.ac.in/online-course-material/secondary-courses/hindi-(201).aspx

Note: Sab content NIOS ka official material hai, sirf padhai
ke liye.
