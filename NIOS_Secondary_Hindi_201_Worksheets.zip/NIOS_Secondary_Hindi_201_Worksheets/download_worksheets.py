#!/usr/bin/env python3
"""NIOS Secondary Hindi (201) - saari worksheets download karo.
Chalao:  python3 download_worksheets.py
(www.nios.ac.in India network/browser se khulta hai)
"""
import os
import sys
import urllib.request

OUTDIR = "worksheets"
LINKS_FILE = "worksheet_links.txt"


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    links_path = os.path.join(here, LINKS_FILE)
    out_path = os.path.join(here, OUTDIR)
    os.makedirs(out_path, exist_ok=True)

    with open(links_path, "r", encoding="utf-8") as f:
        urls = [ln.strip() for ln in f if ln.strip()]

    ok, fail = 0, 0
    for url in urls:
        fname = url.split("/")[-1]
        dest = os.path.join(out_path, fname)
        print(f" -> {fname} ... ", end="", flush=True)
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=180) as r, open(dest, "wb") as out:
                out.write(r.read())
            print("OK")
            ok += 1
        except Exception as e:  # noqa: BLE001
            print(f"FAILED ({e})")
            fail += 1

    print(f"\nDone. Success: {ok}, Failed: {fail}. Files in ./{OUTDIR}")
    if fail:
        sys.exit(1)


if __name__ == "__main__":
    main()
