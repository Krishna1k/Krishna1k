#!/usr/bin/env bash
# NIOS Secondary Hindi (201) - download all worksheets
# Chalao: bash download_worksheets.sh
# (India network/browser se ye links khulte hain)
set -u
OUTDIR="worksheets"
mkdir -p "$OUTDIR"
echo "Downloading NIOS Hindi 201 worksheets into ./$OUTDIR ..."
ok=0; fail=0
while IFS= read -r url; do
  [ -z "$url" ] && continue
  fname="$(basename "$url")"
  echo -n " -> $fname ... "
  if curl -fL --retry 3 --connect-timeout 30 --max-time 180 \
        -A "Mozilla/5.0" -o "$OUTDIR/$fname" "$url" 2>/dev/null; then
    echo "OK"; ok=$((ok+1))
  else
    echo "FAILED"; fail=$((fail+1))
  fi
done < "worksheet_links.txt"
echo "Done. Success: $ok, Failed: $fail. Files in ./$OUTDIR"
