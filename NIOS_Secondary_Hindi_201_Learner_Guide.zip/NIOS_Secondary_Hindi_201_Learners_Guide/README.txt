==========================================================
 NIOS SECONDARY (Class 10) HINDI - 201
 SHIKSHARTHI MARGDARSHIKA (LEARNER'S GUIDE) - COMPLETE
==========================================================

Is zip me kya hai:
------------------
1. NIOS_Hindi_201_Learners_Guide_COMPLETE.pdf   (91 pages)
   -> Ye POORI official Learner's Guide hai - SAARE parts ek
      hi PDF me. NIOS isko ek hi combined booklet ke roop me
      publish karta hai (isi liye website par jo l-1..l-22
      alag files dikhti hain wo isi booklet ke tukde hain).

   Andar kya-kya hai (verified):
     - Prastavna + Learner's Guide ke uddeshya
     - "Paathon ki visheshtayein" = har paath (Lesson 1 se 22)
       ki lesson-wise margdarshika. Jaise:
         1 Bahadur (kahani)
         4 Aahvaan (kavita)
         5 Robert Nursing Home mein (riportaj)
         6 Bharat ki ye bahadur betiyan (feature)
         7 Azaadi (kavita)
         8 Chandra Gahna se Lautti Ber (kavita)
         10 Padhe Kaise (pathan-kaushal)
         12 Ise Jagao (kavita)
         13 Sukhi Rajkumar (kahani)
         14 Boodhi Prithvi ka Dukh (kavita)
         15 Andher Nagri (natak)
         17 Beeti Vibhavari Jaag Ri (kavita)
         18 Nakhoon Kyon Badhte Hain (lalit nibandh)
         19 Shatranj ke Khiladi (lalit nibandh) ...waghairah
     - Prashn-patra ka praroop (question paper format)
     - Namuna prashn-patra (sample question paper)
     - Namuna prashn-patra ke uttar (answers)

2. Instructions.pdf
   -> NIOS ka instruction sheet (study material + guide kaise
      use karein).

Source (official NIOS, verified & downloaded):
----------------------------------------------
  https://cdn.nios.ac.in/cms/documents/2021/May/16/201_learnerguide_hindi.pdf
  Subject page:
  https://www.nios.ac.in/online-course-material/secondary-courses/hindi-(201).aspx

Note: Sab content NIOS (National Institute of Open Schooling)
ka official material hai, sirf padhai ke liye.
